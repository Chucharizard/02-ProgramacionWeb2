import { supabaseRequest, generarId } from './supabase-config.js';

const listar_salas = async () => {
  try {
    console.log("Intentando listar salas desde Supabase...");
    return await supabaseRequest('/salas?select=*');
  } catch (error) {
    console.error('Error al obtener las salas:', error);
    
    if (error.message.includes('404')) {
      console.error('La tabla salas no existe. Por favor, crea la tabla en Supabase.');
      console.log(`
        SQL para crear la tabla:
        create table salas (
          id text primary key,
          sala text not null
        );
      `);
    }
    
    return [];
  }
};

const crear_sala = async (sala) => {
  const id = generarId();
  try {
    return await supabaseRequest('/salas', {
      method: 'POST',
      body: JSON.stringify({ id, sala })
    });
  } catch (error) {
    console.error('Error al crear la sala:', error);
    throw error;
  }
};

const eliminar_sala = async (id) => {
  try {
    return await supabaseRequest(`/salas?id=eq.${id}`, {
      method: 'DELETE'
    });
  } catch (error) {
    console.error('Error al eliminar la sala:', error);
    throw error;
  }
};

const obtener_sala = async (id) => {
  try {
    const response = await supabaseRequest(`/salas?id=eq.${id}&select=*`);
    return response[0];
  } catch (error) {
    console.error('Error al obtener la sala:', error);
    throw error;
  }
};

const actualizar_sala = async (id, sala) => {
  try {
    return await supabaseRequest(`/salas?id=eq.${id}`, {
      method: 'PATCH',
      body: JSON.stringify({ sala })
    });
  } catch (error) {
    console.error('Error al actualizar la sala:', error);
    throw error;
  }
};

export const salaService = {
  listar_salas,
  crear_sala,
  eliminar_sala,
  obtener_sala,
  actualizar_sala
};
